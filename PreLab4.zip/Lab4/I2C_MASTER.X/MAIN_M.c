/*
 * File:   MAIN_M.c
 * Author: HP
 *
 * Created on 2 de agosto de 2023, 03:00 PM
 */
//*****************************************************************************
/* Electronica Digital 2 - 2023
 * Laboratorio 4 - I2C MASTER
 * 
 * 
 * 
 * FUNCION: 
*/
//******************************************************************************
#pragma config  FOSC    = INTRC_NOCLKOUT
#pragma config  WDTE    = OFF
#pragma config  PWRTE   = OFF
#pragma config  MCLRE   = OFF
#pragma config  CP      = OFF
#pragma config  CPD     = OFF
#pragma config  BOREN   = OFF
#pragma config  IESO    = OFF
#pragma config  FCMEN   = OFF
#pragma config  LVP     = OFF

#pragma config  BOR4V   = BOR40V
#pragma config  WRT     = OFF

#include <stdint.h>
#include <xc.h>
#include "LCD.h"
#include "I2CM.h"

#define _XTAL_FREQ  8000000

void setup(void);
uint8_t POT;
uint8_t unidad, decena,centena;

void main(void) {
    setup();
    while(1){
        I2C_Master_Start();
        I2C_Master_Write(0x51);
        POT = I2C_Master_Read(0);
        I2C_Master_Stop();
        __delay_ms(200);
        
        centena = CENTENA(POT);     //Aqui separamos el valor para poder
        decena = DECENA(POT);       //imprimirlos despues
        unidad = UNIDAD(POT);
       
        centena += 48;              //por ser idioma ASCII 48 significa 0
        decena += 48;               //de esta forma obtenemos numeros y no palabras
        unidad += 48;
        
        LCD_CLEAR();               //aqui imprimimos para el LCD
        LCD_XY(1,0);
        LCD_STRING("S1:");
        LCD_XY(2,0);
        LCD_CHAR(centena);
        LCD_STRING(".");
        LCD_CHAR(decena);
        LCD_CHAR(unidad);
        
    }
    return;
}

void setup(void){
    ANSEL = 0x00;
    ANSELH = 0x00;
    
    TRISB = 0x00;
    TRISD = 0x00;
    
    PORTD = 0x00;
    PORTB = 0x00;
    
    //PORTA = 0X00;
    //TRISA = 0X00;
    
    LCD_INIT();
    I2C_Master_Init(100000);        // Inicializar Comuncación I2C
}
